using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("NAnt.NUnit2ReportTasks")]
[assembly: AssemblyDescription("Additional NAnt Tasks")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("COPYRIGHT(C) 2003, Gilles Bayon")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("0.1.2.2")]

[assembly: AssemblyDelaySign(false)]
//[assembly: AssemblyKeyFile(@"")]
//[assembly: AssemblyKeyName("")]
