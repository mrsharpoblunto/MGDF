class 'ConsoleStorageListener'(MGDF.StorageListener)

function ConsoleStorageListener:__init() super()
end

function ConsoleStorageListener:OnChange(node)
	MGDF.system.Logger:Add('Console','called console storage listener')
end 

function init ()
	MGDF.system.Logger:Add('Console','loading console script')
	
	csListener = ConsoleStorageListener()
	
	MGDF.system.StorageTree:AddChild('testNode')
	
	newNode = MGDF.system.StorageTree:GetChild('testNode')
	newNode.IntData = 5
	newNode:AddListener(csListener)
	newNode.IntData = 10 --should result in the derived listener firing and putting an entry into the log file
end

function control ()
	if MGDF.system.Input:IsKeyPress(MGDF.InputManager.KEY_SPACE) then
		MGDF.system:ShutDown()
	end
end